/* WP Ru-max Admin JavaScript */
(function ($) {
    'use strict';

    var currentPage = 1;
    var perPage = 50;
    var historyType = typeof wpRuMaxHistoryType !== 'undefined' ? wpRuMaxHistoryType : '';

    /* -- Helper: AJAX -- */
    function doAjax(action, data, callback, failCallback) {
        data = $.extend({ action: action, nonce: wpRuMax.nonce }, data);
        return $.post(wpRuMax.ajaxUrl, data, function (res) {
            callback(res);
        }).fail(function (xhr) {
            // Обработка сетевых ошибок (500, таймаут и т.д.) — без этого
            // кнопки могли зависнуть навсегда в состоянии «Сохранение...»
            var msg = 'Ошибка сети: ' + (xhr.status || 'нет ответа');
            if (typeof failCallback === 'function') {
                failCallback(msg);
            } else {
                console.error('[wp-ru-max] doAjax failed:', action, msg);
            }
        });
    }

    /* -- Helper: Show Notice -- */
    function showNotice($el, type, message) {
        // Используем .text() вместо .html() — серверные сообщения об ошибках
        // могут содержать HTML-теги, что создаёт риск XSS в панели администратора.
        $el.removeClass('success error info').addClass(type).text(message).fadeIn(200);
    }

    /* -- Token visibility + защита от браузерного автозаполнения -- */
    (function () {
        var $token = $('#bot_token');
        if (!$token.length) { return; }

        /* autocomplete="new-password" не всегда срабатывает в Chrome.
           Дополнительно: восстанавливаем значение из data-token через 300 мс,
           после того как браузер мог подставить сохранённые credentials. */
        var serverToken = $token.data('token');
        if (typeof serverToken === 'string') {
            setTimeout(function () {
                if ($token.val() !== serverToken) {
                    $token.val(serverToken);
                }
            }, 300);
        }

        /* Кнопка «Показать/Скрыть» */
        $('#toggle_token_visibility').on('click', function () {
            if ($token.attr('type') === 'password') {
                $token.attr('type', 'text');
                $(this).text('Скрыть');
            } else {
                $token.attr('type', 'password');
                $(this).text('Показать');
            }
        });
    }());

    /* -- Main Tab -- */
    $('#save_main_settings').on('click', function () {
        var $btn = $(this).prop('disabled', true).text('Сохранение...');
        var data = {
            bot_name: $('#bot_name').val()
        };
        // Не отправляем пустое значение заблокированного поля: сервер
        // сохранит уже существующий токен без риска случайного затирания.
        if ($('#bot_token').length && !$('#bot_token').prop('disabled')) {
            data.bot_token = $('#bot_token').val();
        }
        doAjax('wp_ru_max_save_settings', data, function (res) {
            $btn.prop('disabled', false).text('Сохранить настройки');
            showNotice($('#connection_result'), res.success ? 'success' : 'error', res.success ? res.data : res.data);
        });
    });

    $('#test_connection').on('click', function () {
        var $btn = $(this).prop('disabled', true).text('Проверяем...');
        var $status = $('#bot_status');
        doAjax('wp_ru_max_test_connection', { token: $('#bot_token').val() }, function (res) {
            $btn.prop('disabled', false).text('Проверить подключение');
            if (res.success) {
                showNotice($('#connection_result'), 'success', res.data.message);
                if ($status.length) {
                    $status.html('<span class="wp-ru-max-status-dot status-green">●</span> ' + escHtml(res.data.message || 'Подключено'));
                }
            } else {
                showNotice($('#connection_result'), 'error', res.data ? res.data.message || res.data : 'Ошибка подключения');
                if ($status.length) {
                    var errMsg = res.data ? (res.data.message || res.data) : 'Ошибка подключения';
                    if (typeof errMsg !== 'string') { errMsg = 'Ошибка подключения'; }
                    $status.html('<span class="wp-ru-max-status-dot status-red">●</span> ' + escHtml(errMsg));
                }
            }
        });
    });

    /* -- Post Sender Tab -- */
    $('#post_sender_enabled').on('change', function () {
        $('#post_sender_settings').toggle(this.checked);
        doAjax('wp_ru_max_save_settings', { field: 'post_sender_enabled', value: this.checked ? '1' : '0' }, function () {});
    });

    /* Collect post buttons as JSON — also flushes any pending button from the input fields */
    function collectPostButtons() {
        var pendingText = $('#new_post_btn_text').val().trim();
        var pendingUrl  = $('#new_post_btn_url').val().trim();
        if (pendingText && pendingUrl) {
            var row = '<div class="wp-ru-max-button-row" style="display:flex;gap:8px;margin-bottom:8px;align-items:center;">' +
                '<input type="text" name="post_btn_text[]" value="' + escAttr(pendingText) + '" class="regular-text" placeholder="Название кнопки" style="max-width:160px;" />' +
                '<input type="text" name="post_btn_url[]" value="' + escAttr(pendingUrl) + '" class="regular-text" placeholder="https://..." style="flex:1;" />' +
                '<button type="button" class="button wp-ru-max-remove-btn">Удалить</button>' +
                '</div>';
            $('#post_buttons_list').append(row);
            $('#new_post_btn_text').val('');
            $('#new_post_btn_url').val('');
        }
        var buttons = [];
        $('#post_buttons_list .wp-ru-max-button-row').each(function () {
            var t = $(this).find('input[name="post_btn_text[]"]').val().trim();
            var u = $(this).find('input[name="post_btn_url[]"]').val().trim();
            if (t && u) { buttons.push({ text: t, url: u }); }
        });
        return { post_buttons_json: JSON.stringify(buttons) };
    }

    /* Collect category filter IDs */
    function collectFilterCategories() {
        var cats = [];
        $('input[name="filter_categories[]"]:checked').each(function () { cats.push($(this).val()); });
        return cats;
    }

    /* Collect tag filter IDs */
    function collectFilterTags() {
        var tags = [];
        $('input[name="filter_tags[]"]:checked').each(function () { tags.push($(this).val()); });
        return tags;
    }

    $('#save_post_sender').on('click', function () {
        var $btn = $(this).prop('disabled', true).text('Сохранение...');
        var channels = [];
        $('input[name="channels[]"]').each(function () {
            var v = $(this).val().trim();
            if (v) channels.push(v);
        });
        var postTypes = [];
        $('input[name="post_types[]"]:checked').each(function () { postTypes.push($(this).val()); });

        var filterCats  = collectFilterCategories();
        var filterTags  = collectFilterTags();

        var data = $.extend({
            post_sender_enabled:    $('#post_sender_enabled').is(':checked') ? '1' : '0',
            send_new_post:          $('input[name="send_new_post"]').is(':checked') ? '1' : '0',
            send_updated_post:      $('input[name="send_updated_post"]').is(':checked') ? '1' : '0',
            show_read_more:         $('input[name="show_read_more"]').is(':checked') ? '1' : '0',
            show_action_label:      $('input[name="show_action_label"]').is(':checked') ? '1' : '0',
            show_author_date:       $('input[name="show_author_date"]').is(':checked') ? '1' : '0',
            excerpt_max_chars:      parseInt($('#excerpt_max_chars').val(), 10) || 0,
            post_message_template:  $('#post_message_template').val(),
            send_delay_seconds:     parseInt($('input[name="send_delay_seconds"]:checked').val(), 10) || 0,
            retry_count:            parseInt($('#retry_count').val(), 10) || 0,
            retry_delay_seconds:    parseInt($('#retry_delay_seconds').val(), 10) || 5,
            image_size_limit_mb:    parseFloat($('#image_size_limit_mb').val()) || 5,
            'channels[]':           channels,
            'post_types[]':         postTypes,
            'filter_categories[]':  filterCats,
            'filter_tags[]':        filterTags,
        }, collectPostButtons());

        doAjax('wp_ru_max_save_settings', data, function (res) {
            $btn.prop('disabled', false).text('Сохранить');
            showNotice($('#post_sender_result'), res.success ? 'success' : 'error', res.success ? 'Сохранено!' : res.data);
        });
    });

    $('#test_post_sender').on('click', function () {
        $('#test_chat_id_row').toggle();
    });

    $('#send_test_post').on('click', function () {
        var chatId = $('#test_chat_id').val().trim();
        if (!chatId) { alert('Введите ID чата!'); return; }
        var $btn = $(this).prop('disabled', true).text('Отправка...');
        doAjax('wp_ru_max_send_test_message', { chat_id: chatId, type: 'general' }, function (res) {
            $btn.prop('disabled', false).text('Отправить тест');
            showNotice($('#post_sender_result'), res.success ? 'success' : 'error', res.success ? res.data : res.data);
        });
    });

    /* -- Post Buttons management -- */
    $('#add_post_button').on('click', function () {
        var text = $('#new_post_btn_text').val().trim();
        var url  = $('#new_post_btn_url').val().trim();
        if (!text || !url) { alert('Введите название и URL кнопки.'); return; }
        var row = '<div class="wp-ru-max-button-row" style="display:flex;gap:8px;margin-bottom:8px;align-items:center;">' +
            '<input type="text" name="post_btn_text[]" value="' + escAttr(text) + '" class="regular-text" placeholder="Название кнопки" style="max-width:160px;" />' +
            '<input type="text" name="post_btn_url[]" value="' + escAttr(url) + '" class="regular-text" placeholder="https://..." style="flex:1;" />' +
            '<button type="button" class="button wp-ru-max-remove-btn">Удалить</button>' +
            '</div>';
        $('#post_buttons_list').append(row);
        $('#new_post_btn_text').val('');
        $('#new_post_btn_url').val('');
    });

    /* -- Channel / Chat ID management -- */
    $(document).on('click', '.wp-ru-max-remove-channel', function () {
        var $row = $(this).closest('.wp-ru-max-channel-row');
        if ($row.siblings('.wp-ru-max-channel-row').length === 0) {
            $row.find('input').val('');
        } else {
            $row.remove();
        }
    });

    /* -- Button row remove -- */
    $(document).on('click', '.wp-ru-max-remove-btn', function () {
        $(this).closest('.wp-ru-max-button-row').remove();
    });

    $('#add_channel').on('click', function () {
        $('#channels_list').append('<div class="wp-ru-max-channel-row"><input type="text" name="channels[]" class="regular-text" placeholder="@channel_name или -100123456789" /><button type="button" class="button wp-ru-max-remove-channel">X</button></div>');
    });

    $('#add_notify_channel').on('click', function () {
        $('#notify_chat_ids_list').append('<div class="wp-ru-max-channel-row"><input type="text" name="notify_chat_ids[]" class="regular-text" placeholder="987654321 | My Personal ID" /><button type="button" class="button wp-ru-max-remove-channel">X</button></div>');
    });

    /* -- Push Notification -- */
    $('#send_push_btn').on('click', function () {
        var chatId   = $('#push_chat_id').val().trim();
        var message  = $('#push_message').val().trim();
        var imageUrl = $('#push_image_url').val().trim();

        if (!chatId) { alert('Укажите канал или Chat ID!'); return; }
        if (!message && !imageUrl) { alert('Введите текст сообщения или URL изображения!'); return; }

        var $btn = $(this).prop('disabled', true).text('Отправка...');
        doAjax('wp_ru_max_send_push', {
            chat_id:   chatId,
            message:   message,
            image_url: imageUrl,
        }, function (res) {
            $btn.prop('disabled', false).text('Отправить push');
            showNotice($('#push_result'), res.success ? 'success' : 'error', res.success ? res.data : res.data);
        });
    });

    /* -- Notifications Tab -- */
    $('#notifications_enabled').on('change', function () {
        $('#notifications_settings').toggle(this.checked);
        doAjax('wp_ru_max_save_settings', { field: 'notifications_enabled', value: this.checked ? '1' : '0' }, function () {});
    });

    /* Independent notification rules: unchecked boxes must be saved as false. */
    $('#notify_user_registration, #notify_customer_order').on('change', function () {
        doAjax('wp_ru_max_save_settings', { field: this.name, value: this.checked ? '1' : '0' }, function () {});
    });

    /* WooCommerce filter toggle */
    $('#woo_filter_enabled').on('change', function () {
        $('#woo_statuses_row').toggle(this.checked);
    });

    $('#test_notification').on('click', function () {
        var chatId = $('#notify_test_chat').val().trim();
        if (!chatId) {
            chatId = prompt('Введите ID чата для теста:');
            if (!chatId) return;
        }
        var $btn = $(this).prop('disabled', true).text('Отправка...');
        doAjax('wp_ru_max_send_test_message', { chat_id: chatId, type: 'notification' }, function (res) {
            $btn.prop('disabled', false).text('Тестировать');
            showNotice($('#notify_test_result'), res.success ? 'success' : 'error', res.success ? res.data : res.data);
        });
    });

    /* Collect notification buttons as JSON */
    function collectNotifyButtons() {
        var pendingText = $('#new_notify_btn_text').val().trim();
        var pendingUrl  = $('#new_notify_btn_url').val().trim();
        if (pendingText && pendingUrl) {
            var row = '<div class="wp-ru-max-button-row" style="display:flex;gap:8px;margin-bottom:8px;align-items:center;">' +
                '<input type="text" name="notify_btn_text[]" value="' + escAttr(pendingText) + '" class="regular-text" placeholder="Название кнопки" style="max-width:160px;" />' +
                '<input type="text" name="notify_btn_url[]" value="' + escAttr(pendingUrl) + '" class="regular-text" placeholder="https://..." style="flex:1;" />' +
                '<button type="button" class="button wp-ru-max-remove-btn">Удалить</button>' +
                '</div>';
            $('#notify_buttons_list').append(row);
            $('#new_notify_btn_text').val('');
            $('#new_notify_btn_url').val('');
        }
        var buttons = [];
        $('#notify_buttons_list .wp-ru-max-button-row').each(function () {
            var t = $(this).find('input[name="notify_btn_text[]"]').val().trim();
            var u = $(this).find('input[name="notify_btn_url[]"]').val().trim();
            if (t && u) { buttons.push({ text: t, url: u }); }
        });
        return { notify_buttons_json: JSON.stringify(buttons) };
    }

    $('#save_notifications').on('click', function () {
        var $btn = $(this).prop('disabled', true).text('Сохранение...');
        var chatIds = [];
        $('input[name="notify_chat_ids[]"]').each(function () {
            var v = $(this).val().trim();
            if (v) chatIds.push(v);
        });

        var wooStatuses = [];
        $('input[name="woo_notify_statuses[]"]:checked').each(function () {
            wooStatuses.push($(this).val());
        });

        var data = $.extend({
            notifications_enabled:      $('#notifications_enabled').is(':checked') ? '1' : '0',
            notify_from_email:          $('#notify_from_email').val(),
            'notify_chat_ids[]':        chatIds,
            notify_template:            $('#notify_template').val(),
            notify_format:              $('input[name="notify_format"]:checked').val(),
            notify_plugin_updates:      $('input[name="notify_plugin_updates"]').is(':checked') ? '1' : '0',
            notify_site_errors:         $('input[name="notify_site_errors"]').is(':checked') ? '1' : '0',
            // Передаём оба независимых правила и при общем сохранении.
            // Иначе общий AJAX-запрос мог перезаписать отдельное сохранение
            // снятой галочки старым значением true.
            notify_user_registration:   $('input[name="notify_user_registration"]').is(':checked') ? '1' : '0',
            notify_customer_order:      $('input[name="notify_customer_order"]').is(':checked') ? '1' : '0',
            woo_filter_enabled:         $('input[name="woo_filter_enabled"]').is(':checked') ? '1' : '0',
            'woo_notify_statuses[]':    wooStatuses,
            general_dedup_enabled:      $('input[name="general_dedup_enabled"]').is(':checked') ? '1' : '0',
            general_dedup_ttl:          parseInt($('#general_dedup_ttl').val(), 10) || 30,
        }, collectNotifyButtons());

        doAjax('wp_ru_max_save_settings', data, function (res) {
            $btn.prop('disabled', false).text('Сохранить');
            showNotice($('#notifications_result'), res.success ? 'success' : 'error', res.success ? 'Сохранено!' : res.data);
        });
    });

    /* -- Notify Button management -- */
    $('#add_notify_button').on('click', function () {
        var text = $('#new_notify_btn_text').val().trim();
        var url  = $('#new_notify_btn_url').val().trim();
        if (!text || !url) { alert('Введите название и URL кнопки.'); return; }
        var row = '<div class="wp-ru-max-button-row" style="display:flex;gap:8px;margin-bottom:8px;align-items:center;">' +
            '<input type="text" name="notify_btn_text[]" value="' + escAttr(text) + '" class="regular-text" placeholder="Название кнопки" style="max-width:160px;" />' +
            '<input type="text" name="notify_btn_url[]" value="' + escAttr(url) + '" class="regular-text" placeholder="https://..." style="flex:1;" />' +
            '<button type="button" class="button wp-ru-max-remove-btn">Удалить</button>' +
            '</div>';
        $('#notify_buttons_list').append(row);
        $('#new_notify_btn_text').val('');
        $('#new_notify_btn_url').val('');
    });

    /* -- Advanced Tab -- */
    $('#save_advanced').on('click', function () {
        var $btn = $(this).prop('disabled', true).text('Сохранение...');
        doAjax('wp_ru_max_save_settings', {
            send_post_image:        $('#send_post_image').is(':checked') ? '1' : '0',
            send_files_by_url:      $('#send_files_by_url').is(':checked') ? '1' : '0',
            enable_bot_api_log:     $('#enable_bot_api_log').is(':checked') ? '1' : '0',
            enable_post_sender_log: $('#enable_post_sender_log').is(':checked') ? '1' : '0',
            delete_on_uninstall:    $('#delete_on_uninstall').is(':checked') ? '1' : '0',
            share_button_enabled:   $('#share_button_enabled').is(':checked') ? '1' : '0',
            max_oauth_enabled:      $('#max_oauth_enabled').is(':checked') ? '1' : '0',
            max_oauth_bot_username: $('#max_oauth_bot_username').val(),
        }, function (res) {
            $btn.prop('disabled', false).text('Сохранить');
            showNotice($('#advanced_result'), res.success ? 'success' : 'error', res.success ? 'Сохранено!' : res.data);
        });
    });

    /* -- Chat Widget Tab -- */
    $('#chat_widget_enabled').on('change', function () {
        $('#chat_widget_settings').toggle(this.checked);
        doAjax('wp_ru_max_save_settings', { field: 'chat_widget_enabled', value: this.checked ? '1' : '0' }, function () {});
    });

    $('input[name="chat_widget_size"]').on('change', function () {
        var sizes = { small: 32, medium: 64, large: 80 };
        var px = sizes[$(this).val()] || 64;
        $('#preview_icon_img').attr('width', px).attr('height', px);
        $('label.wp-ru-max-size-option').removeClass('selected');
        $(this).closest('label').addClass('selected');
    });

    $('#chat_widget_message').on('input', function () {
        $('#preview_message').text($(this).val());
    });

    $('#chat_widget_message_enabled').on('change', function () {
        $('#preview_balloon').toggle(this.checked);
    });

    $('input[name="chat_widget_animation"]').on('change', function () {
        var $icon = $('.wp-ru-max-preview-widget .preview-icon');
        $icon.removeClass('wp-ru-max-anim-pulse wp-ru-max-anim-ripple wp-ru-max-anim-bounce wp-ru-max-anim-shake wp-ru-max-anim-glow wp-ru-max-anim-rotate');
        var val = $(this).val();
        if (val && val !== 'none') {
            $icon.addClass('wp-ru-max-anim-' + val);
        }
        $(this).closest('div').find('label').each(function () {
            var $lbl = $(this);
            var checked = $lbl.find('input[type="radio"]').is(':checked');
            $lbl.css({
                background: checked ? '#e8f0fe' : '#f8f9fa',
                'border-color': checked ? '#4a90d9' : '#ddd'
            });
        });
    });

    $('input[name="chat_widget_position"]').on('change', function () {
        var $widget = $('.wp-ru-max-preview-widget');
        if ($(this).val() === 'left') {
            $widget.css({ right: 'auto', left: '20px', 'align-items': 'flex-start' });
        } else {
            $widget.css({ left: 'auto', right: '20px', 'align-items': 'flex-end' });
        }
    });

    $('#save_chat_widget').on('click', function () {
        var $btn = $(this).prop('disabled', true).text('Сохранение...');
        var chatUrl = $('#chat_widget_url').val().trim();
        doAjax('wp_ru_max_save_settings', {
            chat_widget_enabled:       $('#chat_widget_enabled').is(':checked') ? '1' : '0',
            chat_widget_size:          $('input[name="chat_widget_size"]:checked').val() || 'medium',
            chat_widget_url:           chatUrl,
            chat_widget_message_enabled: $('#chat_widget_message_enabled').is(':checked') ? '1' : '0',
            chat_widget_message:       $('#chat_widget_message').val(),
            chat_widget_position:      $('input[name="chat_widget_position"]:checked').val() || 'right',
            chat_widget_bottom_offset: parseInt($('#chat_widget_bottom_offset').val(), 10) || 20,
            chat_widget_show_delay:    parseInt($('input[name="chat_widget_show_delay"]:checked').val(), 10) || 0,
            chat_widget_hide_delay:    parseInt($('input[name="chat_widget_hide_delay"]:checked').val(), 10) || 0,
            chat_widget_repeat_delay:  parseInt($('input[name="chat_widget_repeat_delay"]:checked').val(), 10) || 0,
            chat_widget_sound:         $('input[name="chat_widget_sound"]:checked').val() || 'none',
            chat_widget_sound_delay:   parseInt($('input[name="chat_widget_sound_delay"]:checked').val(), 10) || 3,
            chat_widget_sound_pages:   $('input[name="chat_widget_sound_pages"]:checked').val() || 'all',
            chat_widget_sound_specific_pages: $('#chat_widget_sound_specific_pages').val() || '',
            chat_widget_sound_once_per_session: $('#chat_widget_sound_once_per_session').is(':checked') ? '1' : '0',
            chat_widget_animation:     $('input[name="chat_widget_animation"]:checked').val() || 'none',
            chat_widget_retention_enabled:        $('#chat_widget_retention_enabled').is(':checked') ? '1' : '0',
            chat_widget_retention_title:          $('#chat_widget_retention_title').val() || '',
            chat_widget_retention_message:        $('#chat_widget_retention_message').val() || '',
            chat_widget_retention_text_align:     $('input[name="chat_widget_retention_text_align"]:checked').val() || 'left',
            chat_widget_retention_buttons_align:  $('input[name="chat_widget_retention_buttons_align"]:checked').val() || 'right',
            chat_widget_retention_btn_radius:     parseInt($('#chat_widget_retention_btn_radius').val(), 10) || 0,
            chat_widget_retention_stay_text:      $('#chat_widget_retention_stay_text').val() || 'Остаться',
            chat_widget_retention_leave_text:     $('#chat_widget_retention_leave_text').val() || 'Все равно уйти',
            chat_widget_retention_stay_bg:        $('input[name="chat_widget_retention_stay_bg"]').val() || '#4a90d9',
            chat_widget_retention_stay_color:     $('input[name="chat_widget_retention_stay_color"]').val() || '#ffffff',
            chat_widget_retention_leave_bg:       $('input[name="chat_widget_retention_leave_bg"]').val() || '#f0f0f0',
            chat_widget_retention_leave_color:    $('input[name="chat_widget_retention_leave_color"]').val() || '#555555',
            chat_widget_utm_source:    $('#chat_widget_utm_source').val() || '',
            chat_widget_utm_medium:    $('#chat_widget_utm_medium').val() || '',
            chat_widget_utm_campaign:  $('#chat_widget_utm_campaign').val() || '',
            chat_widget_utm_content:   $('#chat_widget_utm_content').val() || '',
            chat_widget_ya_metrika_enabled:  $('#chat_widget_ya_metrika_enabled').is(':checked') ? '1' : '0',
            chat_widget_ya_metrika_counter:  $('#chat_widget_ya_metrika_counter').val() || '',
            chat_widget_ya_metrika_goal:     $('#chat_widget_ya_metrika_goal').val() || 'chat_widget_click',
        }, function (res) {
            $btn.prop('disabled', false).text('Сохранить');
            if (res.success) {
                var notice = 'Сохранено! Обновите страницу сайта, чтобы увидеть иконку.';
                if (!chatUrl) {
                    notice += ' Ссылка не заполнена — иконка покажется, но нажатие никуда не ведёт. Введите ссылку на ваш MAX чат.';
                }
                showNotice($('#chat_widget_result'), 'success', notice);
            } else {
                showNotice($('#chat_widget_result'), 'error', res.data);
            }
        });
    });

    /* -- Sound preview buttons (admin panel) -- */
    function adminPlaySound(type) {
        try {
            var AC  = window.AudioContext || window.webkitAudioContext;
            if (!AC) { alert('Ваш браузер не поддерживает Web Audio API'); return; }
            var ctx = new AC();

            function tone(freq, startOff, vol, dur) {
                var osc  = ctx.createOscillator();
                var gain = ctx.createGain();
                osc.type = 'sine';
                osc.connect(gain);
                gain.connect(ctx.destination);
                var t = ctx.currentTime + startOff;
                osc.frequency.setValueAtTime(freq, t);
                gain.gain.setValueAtTime(0, t);
                gain.gain.linearRampToValueAtTime(vol, t + 0.02);
                gain.gain.exponentialRampToValueAtTime(0.001, t + dur);
                osc.start(t);
                osc.stop(t + dur + 0.05);
            }

            if (type === 'sound1') {
                tone(880, 0, 0.18, 0.35);
                tone(1100, 0.22, 0.12, 0.28);
            } else if (type === 'sound2') {
                var osc  = ctx.createOscillator();
                var gain = ctx.createGain();
                osc.type = 'sine';
                osc.connect(gain);
                gain.connect(ctx.destination);
                var t = ctx.currentTime;
                osc.frequency.setValueAtTime(200, t);
                osc.frequency.exponentialRampToValueAtTime(900, t + 0.12);
                osc.frequency.exponentialRampToValueAtTime(600, t + 0.28);
                gain.gain.setValueAtTime(0, t);
                gain.gain.linearRampToValueAtTime(0.38, t + 0.05);
                gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);
                osc.start(t);
                osc.stop(t + 0.5);
            } else if (type === 'sound3') {
                tone(523.25, 0, 0.12, 0.55);
            } else if (type === 'sound4' || type === 'sound5' || type === 'sound6') {
                /* MP3-based sounds — play via HTML5 Audio */
                /* sound7 убран: файл assets/sounds/sound7.mp3 не существует */
                var soundsUrl = (typeof wpRuMax !== 'undefined' && wpRuMax.soundsUrl) ? wpRuMax.soundsUrl : '';
                if (soundsUrl) {
                    var filenames = { 'sound4': 'sound4.mp3', 'sound5': 'sound5.mp3', 'sound6': 'sound6.mp3' };
                    var audio = new Audio(soundsUrl + filenames[type]);
                    audio.volume = 0.7;
                    var p = audio.play();
                    if (p !== undefined) { p.catch(function(){}); }
                }
                return;
            }
        } catch(e) { console.warn('WP Ru-max audio error:', e); }
    }

    $(document).on('click', '.wp-ru-max-preview-sound', function (e) {
        e.preventDefault();
        adminPlaySound($(this).data('sound'));
    });

    /* -- Очередь отложенной отправки: обработать сейчас -- */
    $('#flush_queue_now').on('click', function () {
        var $btn = $(this).prop('disabled', true).text('Обработка...');
        doAjax('wp_ru_max_flush_queue', {}, function (res) {
            $btn.prop('disabled', false).text('Обработать очередь сейчас');
            showNotice($('#flush_queue_result'), res.success ? 'success' : 'error', res.success ? res.data.message : res.data);
        });
    });

    /* -- History Tab -- */
    var currentLogsXhr = null; // Хранит активный XHR для отмены дублирующих запросов.

    function loadLogs(page) {
        currentPage = page || 1;
        var offset = (currentPage - 1) * perPage;

        // Отменяем предыдущий запрос, если он ещё не завершён (клик по пагинации).
        if (currentLogsXhr && currentLogsXhr.readyState !== 4) {
            currentLogsXhr.abort();
        }

        $('#history_table_wrap').html('<div class="wp-ru-max-loading">Загрузка...</div>');

        currentLogsXhr = doAjax('wp_ru_max_get_logs', { limit: perPage, offset: offset, type: historyType }, function (res) {
            if (!res.success) {
                $('#history_table_wrap').html('<p>Ошибка загрузки логов.</p>');
                return;
            }
            var logs = res.data.logs;
            var total = res.data.total;
            var totalPages = Math.ceil(total / perPage);

            if (!logs || logs.length === 0) {
                $('#history_table_wrap').html('<p style="padding:20px;color:#94a3b8;">Записей не найдено.</p>');
            } else {
                var typeLabels = {
                    api:           'MAX / API',
                    post_sender:   'Публикации MAX',
                    notifications: 'Уведомления',
                    test:          'Тест',
                    settings:      'Настройки',
                    direct_access: 'Прямой доступ',
                    social:        'Соц. сети',
                    autopost:      'Автопостинг',
                    push:          'Push',
                };
                var html = '<table><thead><tr><th>ID</th><th>Время</th><th>Тип</th><th>Статус</th><th>Событие</th><th>Детали</th></tr></thead><tbody>';
                $.each(logs, function (i, log) {
                    var typeLabel = typeLabels[log.event_type] || log.event_type;
                    var statusClass = 'log-status-' + log.status;
                    var typeClass   = 'type-' + log.event_type;
                    var hasDetails  = log.details && log.details.trim();
                    html += '<tr>';
                    html += '<td>' + log.id + '</td>';
                    html += '<td style="white-space:nowrap;font-size:12px;">' + log.event_time + '</td>';
                    html += '<td><span class="log-type-badge ' + typeClass + '">' + typeLabel + '</span></td>';
                    html += '<td class="' + statusClass + '">' + log.status + '</td>';
                    html += '<td>' + escHtml(log.event_data) + '</td>';
                    html += '<td>';
                    if (hasDetails) {
                        html += '<span class="toggle-details" data-id="' + log.id + '">показать ▼</span>';
                        html += '<pre class="log-details" id="details-' + log.id + '">' + escHtml(log.details) + '</pre>';
                    } else {
                        html += '—';
                    }
                    html += '</td></tr>';
                });
                html += '</tbody></table>';
                $('#history_table_wrap').html(html);
            }

            $('#page_info').text('Страница ' + currentPage + ' из ' + Math.max(1, totalPages) + ' (всего: ' + total + ')');
            $('#prev_page').prop('disabled', currentPage <= 1);
            $('#next_page').prop('disabled', currentPage >= totalPages);
        });
    }

    $(document).on('click', '.toggle-details', function () {
        var id  = $(this).data('id');
        var $pre = $('#details-' + id);
        if ($pre.is(':visible')) {
            $pre.hide();
            $(this).text('показать ▼');
        } else {
            $pre.show();
            $(this).text('скрыть ▲');
        }
    });

    $('#prev_page').on('click', function () { loadLogs(currentPage - 1); });
    $('#next_page').on('click', function () { loadLogs(currentPage + 1); });
    $('#refresh_logs').on('click', function () { loadLogs(currentPage); });

    $('#clear_logs').on('click', function () {
        if (!confirm('Вы уверены, что хотите очистить логи?')) return;
        doAjax('wp_ru_max_clear_logs', { type: historyType }, function (res) {
            if (res.success) loadLogs(1);
        });
    });

    /* -- Global Test from History -- */
    $('#send_global_test').on('click', function () {
        var chatId = $('#global_test_chat').val().trim();
        if (!chatId) {
            chatId = prompt('Введите ID чата или канала для тестового сообщения:');
            if (!chatId) return;
        }
        var $btn = $(this).prop('disabled', true).text('Отправка...');
        doAjax('wp_ru_max_send_test_message', { chat_id: chatId, type: 'general' }, function (res) {
            $btn.prop('disabled', false).text('Тест подключения');
            showNotice($('#history_test_result'), res.success ? 'success' : 'error', res.success ? res.data : res.data);
            loadLogs(1);
        });
    });

    /* Auto-load logs on history tab */
    if ($('#history_table_wrap').length) {
        loadLogs(1);
    }

    /* -- Autoposting: tabs, calendar and drag-and-drop -- */
    (function () {
        var $root = $('#wp-ru-max-autopost');
        if (!$root.length) { return; }

        var calendarDate = new Date();
        calendarDate.setDate(1);
        var calendarData = { events: [], available_posts: [], networks: {} };
        var monthNames = [
            'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
            'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
        ];

        function monthValue() {
            return calendarDate.getFullYear() + '-' + ('0' + (calendarDate.getMonth() + 1)).slice(-2);
        }

        function setAutoNotice(selector, ok, text) {
            var $el = $(selector);
            if (!$el.length) { return; }
            $el.removeClass('success error').addClass(ok ? 'success' : 'error').text(text).show();
        }

        function loadAutopostCalendar() {
            doAjax('wp_ru_max_autopost_calendar', { month: monthValue() }, function (res) {
                if (!res || !res.success) {
                    setAutoNotice('#wp-ru-max-calendar-result', false, (res && res.data) || 'Не удалось загрузить календарь.');
                    return;
                }
                renderAutopostCalendar(res.data);
                renderAutopostQueue(res.data.queue || [], res.data.networks || {});
                $('#wp-ru-max-autopost-total').text(res.data.summary.total);
                $('#wp-ru-max-autopost-errors').text(res.data.summary.errors);
            }, function (msg) {
                setAutoNotice('#wp-ru-max-calendar-result', false, msg);
            });
        }

        function renderAutopostQueue(queue, networkLabels) {
            var $queue = $('#wp-ru-max-autopost-queue');
            if (!$queue.length) { return; }
            if (!queue || !queue.length) {
                $queue.html('<p class="wp-ru-max-autopost-queue-empty">Очередь пуста. Все запланированные статьи уже опубликованы или заданий нет.</p>');
                return;
            }

            var html = '<div class="wp-ru-max-autopost-queue-list">';
            $.each(queue, function (_, item) {
                var states = [];
                $.each(item.statuses || {}, function (network, state) {
                    var label = networkLabels[network] || network;
                    states.push(label + ': ' + state);
                });
                var errors = [];
                $.each(item.errors || {}, function (network, message) {
                    errors.push((networkLabels[network] || network) + ': ' + message);
                });
                html += '<details class="wp-ru-max-autopost-queue-item">';
                html += '<summary><a href="' + escAttr(item.edit_url || '#') + '">' + escHtml(item.title || '(без названия)') + '</a>';
                html += '<span class="wp-ru-max-autopost-queue-date">' + escHtml(item.datetime || 'без даты') + '</span></summary>';
                html += '<div class="wp-ru-max-autopost-queue-details">';
                html += '<div><strong>Сети:</strong> ' + escHtml((item.networks || []).map(function (network) {
                    return networkLabels[network] || network;
                }).join(', ') || 'не указаны') + '</div>';
                html += '<div><strong>Состояние:</strong> ' + escHtml(states.join(', ') || 'pending') + '</div>';
                if (errors.length) {
                    html += '<div class="wp-ru-max-autopost-queue-error"><strong>Ошибки:</strong> ' + escHtml(errors.join(' | ')) + '</div>';
                }
                html += '</div></details>';
            });
            html += '</div>';
            $queue.html(html);
        }

        function renderAutopostCalendar(data) {
            calendarData = data || calendarData;
            var eventsByDate = {};
            $.each(calendarData.events || [], function (_, event) {
                if (!eventsByDate[event.date]) { eventsByDate[event.date] = []; }
                eventsByDate[event.date].push(event);
            });
            $('#wp-ru-max-calendar-title').text(monthNames[calendarDate.getMonth()] + ' ' + calendarDate.getFullYear());
            var firstDay = new Date(calendarDate.getFullYear(), calendarDate.getMonth(), 1);
            var daysInMonth = new Date(calendarDate.getFullYear(), calendarDate.getMonth() + 1, 0).getDate();
            var offset = (firstDay.getDay() + 6) % 7;
            var html = '<div class="wp-ru-max-calendar-grid">';
            $.each(['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'], function (_, day) {
                html += '<div class="wp-ru-max-calendar-weekday">' + day + '</div>';
            });
            for (var blank = 0; blank < offset; blank++) {
                html += '<div class="wp-ru-max-calendar-day is-empty"></div>';
            }
            for (var dayNumber = 1; dayNumber <= daysInMonth; dayNumber++) {
                var dateKey = calendarData.month + '-' + ('0' + dayNumber).slice(-2);
                var today = new Date();
                var isToday = today.getFullYear() === calendarDate.getFullYear() &&
                    today.getMonth() === calendarDate.getMonth() && today.getDate() === dayNumber;
                html += '<div class="wp-ru-max-calendar-day' + (isToday ? ' is-today' : '') + '" data-date="' + dateKey + '" role="button" tabindex="0" aria-label="Запланировать публикацию на ' + dateKey + '">';
                html += '<div class="wp-ru-max-calendar-day-number">' + dayNumber + '</div>';
                $.each(eventsByDate[dateKey] || [], function (_, event) {
                    var scheduled = event.type === 'scheduled' || event.type === 'error' || event.scheduled;
                    var completed = event.type === 'completed';
                    var movable = scheduled || completed;
                    var hasError = event.type === 'error';
                    var stateText = '';
                    if (event.states) {
                        var states = [];
                        $.each(event.states, function (network, state) {
                            states.push(network + ': ' + state);
                            if (state === 'error') {
                                hasError = true;
                            }
                        });
                        stateText = states.join(', ');
                    }
                    var eventClasses = completed ? ['is-scheduled', 'is-completed'] : (scheduled ? ['is-scheduled'] : ['is-published']);
                    if (hasError) {
                        eventClasses.push('is-error');
                    }
                    html += '<div class="wp-ru-max-calendar-event ' + eventClasses.join(' ') + '"' +
                        (movable ? ' draggable="true" data-post-id="' + event.id + '" data-datetime="' + escAttr(event.datetime) + '" data-networks="' + escAttr(JSON.stringify(event.networks || [])) + '"' : '') +
                        ' title="' + escAttr(event.title + (stateText ? ' — ' + stateText : '')) + '">';
                    html += '<span class="wp-ru-max-calendar-event-time">' + (event.datetime || '').slice(11, 16) + '</span> ';
                    html += '<span>' + escHtml(event.title || '(без названия)') + '</span>';
                    if (scheduled) {
                        html += '<span class="wp-ru-max-calendar-event-actions">';
                        html += '<button type="button" class="wp-ru-max-autopost-run" data-post-id="' + event.id + '" title="Опубликовать сейчас">▶</button>';
                        html += '<button type="button" class="wp-ru-max-autopost-delete" data-post-id="' + event.id + '" title="Удалить задание">×</button>';
                        html += '</span>';
                    }
                    html += '</div>';
                });
                html += '</div>';
            }
            html += '</div>';
            $('#wp-ru-max-calendar').html(html);
        }

        function closeCalendarScheduleModal() {
            $root.find('.wp-ru-max-calendar-modal').remove();
        }

        function openCalendarScheduleModal(date, postId, time, selectedNetworks) {
            closeCalendarScheduleModal();
            var posts = calendarData.available_posts || [];
            var configuredNetworks = calendarData.networks || {};
            var selectedPostId = String(postId || '');
            var selectedTime = time || '10:00';
            var selected = $.map(selectedNetworks || [], function (network) {
                return String(network);
            });
            var postOptions = '<option value="">Выберите статью</option>';
            $.each(posts, function (_, post) {
                postOptions += '<option value="' + escAttr(String(post.id)) + '"' +
                    (String(post.id) === selectedPostId ? ' selected' : '') + '>' +
                    escHtml(post.title || '(без названия)') + '</option>';
            });
            var networkControls = '';
            $.each(configuredNetworks, function (network, label) {
                networkControls += '<label class="wp-ru-max-calendar-network">' +
                    '<input type="checkbox" value="' + escAttr(network) + '"' +
                    (selected.indexOf(String(network)) !== -1 ? ' checked' : '') + '> ' +
                    escHtml(label) + '</label>';
            });
            if (!networkControls) {
                networkControls = '<p class="description">Сначала подключите социальную сеть в настройках плагина.</p>';
            }
            var html = '<div class="wp-ru-max-calendar-modal" role="dialog" aria-modal="true">' +
                '<div class="wp-ru-max-calendar-modal-backdrop"></div>' +
                '<div class="wp-ru-max-calendar-modal-card">' +
                '<button type="button" class="wp-ru-max-calendar-modal-close" aria-label="Закрыть">×</button>' +
                '<h3>Запланировать публикацию</h3>' +
                '<p class="description">Выберите статью и одну или несколько социальных сетей.</p>' +
                '<label class="wp-ru-max-calendar-modal-field">Статья' +
                '<select class="wp-ru-max-calendar-post">' + postOptions + '</select></label>' +
                '<label class="wp-ru-max-calendar-modal-field">Дата и время' +
                '<input type="datetime-local" class="wp-ru-max-calendar-datetime" value="' + escAttr(date + 'T' + selectedTime) + '"></label>' +
                '<div class="wp-ru-max-calendar-modal-field"><strong>Социальные сети</strong>' +
                '<div class="wp-ru-max-calendar-network-list">' + networkControls + '</div></div>' +
                '<div class="wp-ru-max-calendar-modal-actions">' +
                '<button type="button" class="button wp-ru-max-calendar-modal-cancel">Отмена</button>' +
                '<button type="button" class="button button-primary wp-ru-max-calendar-modal-save">Сохранить</button>' +
                '</div></div></div>';
            $root.append(html);
        }

        $root.on('click', '[data-autopost-tab]', function () {
            var tab = $(this).data('autopost-tab');
            $root.find('[data-autopost-tab]').removeClass('is-active');
            $(this).addClass('is-active');
            $root.find('[data-autopost-pane]').removeClass('is-active');
            $root.find('[data-autopost-pane="' + tab + '"]').addClass('is-active');
            if (tab === 'calendar') {
                loadAutopostCalendar();
            } else if ($(this).data('autopost-focus-queue')) {
                window.setTimeout(function () {
                    var $queue = $('#wp-ru-max-autopost-queue');
                    if ($queue.length) {
                        $queue[0].scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }
                }, 0);
            }
        });
        $root.on('click', '.wp-ru-max-calendar-day:not(.is-empty)', function (event) {
            if ($(event.target).closest('.wp-ru-max-calendar-event, button, a, input, select').length) {
                return;
            }
            var $day = $(this);
            openCalendarScheduleModal(String($day.data('date')), '', '10:00', []);
        });
        $root.on('keydown', '.wp-ru-max-calendar-day:not(.is-empty)', function (event) {
            if (event.key !== 'Enter' && event.key !== ' ') {
                return;
            }
            if ($(event.target).closest('.wp-ru-max-calendar-event, button, a, input, select').length) {
                return;
            }
            event.preventDefault();
            openCalendarScheduleModal(String($(this).data('date')), '', '10:00', []);
        });
        $root.on('click', '.wp-ru-max-calendar-modal-close, .wp-ru-max-calendar-modal-cancel, .wp-ru-max-calendar-modal-backdrop', function () {
            closeCalendarScheduleModal();
        });
        $root.on('click', '.wp-ru-max-calendar-modal-save', function () {
            var $modal = $(this).closest('.wp-ru-max-calendar-modal');
            var postId = parseInt($modal.find('.wp-ru-max-calendar-post').val(), 10) || 0;
            var datetime = ($modal.find('.wp-ru-max-calendar-datetime').val() || '').replace('T', ' ');
            var networks = [];
            $modal.find('.wp-ru-max-calendar-network-list input:checked').each(function () {
                networks.push($(this).val());
            });
            if (!postId) {
                setAutoNotice('#wp-ru-max-calendar-result', false, 'Выберите статью.');
                return;
            }
            if (!networks.length) {
                setAutoNotice('#wp-ru-max-calendar-result', false, 'Выберите хотя бы одну социальную сеть.');
                return;
            }
            var $button = $(this).prop('disabled', true).text('Сохранение…');
            doAjax('wp_ru_max_autopost_save_meta', {
                post_id: postId,
                networks: networks,
                datetime: datetime
            }, function (res) {
                if (res && res.success) {
                    closeCalendarScheduleModal();
                    setAutoNotice('#wp-ru-max-calendar-result', true, 'Задание автопостинга сохранено.');
                    loadAutopostCalendar();
                } else {
                    $button.prop('disabled', false).text('Сохранить');
                    setAutoNotice('#wp-ru-max-calendar-result', false, (res && res.data) || 'Не удалось сохранить задание.');
                }
            });
        });
        $('#wp-ru-max-calendar-prev').on('click', function () {
            calendarDate.setMonth(calendarDate.getMonth() - 1);
            loadAutopostCalendar();
        });
        $('#wp-ru-max-calendar-next').on('click', function () {
            calendarDate.setMonth(calendarDate.getMonth() + 1);
            loadAutopostCalendar();
        });
        $('#wp-ru-max-calendar-today').on('click', function () {
            calendarDate = new Date();
            calendarDate.setDate(1);
            loadAutopostCalendar();
        });
        $('#wp-ru-max-autopost-refresh').on('click', function () {
            loadAutopostCalendar();
            setAutoNotice('#wp-ru-max-autopost-result', true, 'Состояние очереди обновлено.');
        });
        $root.on('dragstart', '.wp-ru-max-calendar-event.is-scheduled', function (event) {
            var networks = [];
            try {
                networks = JSON.parse($(this).attr('data-networks') || '[]');
            } catch (e) {}
            event.originalEvent.dataTransfer.setData('text/plain', JSON.stringify({
                postId: $(this).data('post-id'),
                datetime: $(this).data('datetime'),
                networks: networks
            }));
            $(this).addClass('is-dragging');
        });
        $root.on('dragend', '.wp-ru-max-calendar-event', function () {
            $(this).removeClass('is-dragging');
        });
        $root.on('dragover', '.wp-ru-max-calendar-day:not(.is-empty)', function (event) {
            event.preventDefault();
            $(this).addClass('is-drop-target');
        });
        $root.on('dragleave', '.wp-ru-max-calendar-day', function () {
            $(this).removeClass('is-drop-target');
        });
        $root.on('drop', '.wp-ru-max-calendar-day:not(.is-empty)', function (event) {
            event.preventDefault();
            $(this).removeClass('is-drop-target');
            var raw = event.originalEvent.dataTransfer.getData('text/plain');
            var source;
            try { source = JSON.parse(raw); } catch (e) { return; }
            var time = (source.datetime || '').slice(11, 16) || '10:00';
            openCalendarScheduleModal(
                String($(this).data('date')),
                source.postId,
                time,
                source.networks || []
            );
        });
        $root.on('click', '.wp-ru-max-autopost-delete', function (event) {
            event.stopPropagation();
            var postId = $(this).data('post-id');
            if (!window.confirm('Удалить задание автопостинга для этой записи?')) { return; }
            doAjax('wp_ru_max_autopost_delete', { post_id: postId }, function (res) {
                setAutoNotice('#wp-ru-max-calendar-result', !!(res && res.success), (res && res.data) || 'Ошибка удаления.');
                loadAutopostCalendar();
            });
        });
        $root.on('click', '.wp-ru-max-autopost-run', function (event) {
            event.stopPropagation();
            var $button = $(this).prop('disabled', true);
            var networks = [];
            try {
                networks = JSON.parse($button.closest('.wp-ru-max-calendar-event').attr('data-networks') || '[]');
            } catch (e) {}
            if (!networks.length) {
                $button.prop('disabled', false);
                openCalendarScheduleModal(
                    String($button.closest('.wp-ru-max-calendar-day').data('date')),
                    $button.data('post-id'),
                    String($button.closest('.wp-ru-max-calendar-event').data('datetime') || '').slice(11, 16) || '10:00',
                    networks
                );
                return;
            }
            doAjax('wp_ru_max_autopost_run', { post_id: $button.data('post-id'), networks: networks }, function (res) {
                $button.prop('disabled', false);
                setAutoNotice('#wp-ru-max-calendar-result', !!(res && res.success), (res && res.data && res.data.message) || (res && res.data) || 'Ошибка запуска.');
                loadAutopostCalendar();
            });
        });
        $root.on('click', '.wp-ru-max-autopost-save-settings', function () {
            var $button = $(this).prop('disabled', true).text('Сохранение…');
            doAjax('wp_ru_max_autopost_save_settings', {
                enabled: $('#autopost_enabled').is(':checked') ? 1 : 0,
                default_time: $('#autopost_default_time').val(),
                retry_attempts: $('#autopost_retry_attempts').val(),
                retry_delay_minutes: $('#autopost_retry_delay').val(),
                notify_enabled: $('#autopost_notify_enabled').is(':checked') ? 1 : 0,
                notify_emails: $('#autopost_notify_emails').val(),
                notify_on_success: $('#autopost_notify_success').is(':checked') ? 1 : 0,
                notify_on_error: $('#autopost_notify_error').is(':checked') ? 1 : 0
            }, function (res) {
                $button.prop('disabled', false).text('Сохранить настройки');
                setAutoNotice('#wp-ru-max-autopost-settings-result', !!(res && res.success), (res && res.data) || 'Ошибка сохранения.');
            });
        });
        /* Загружаем текущий месяц сразу, чтобы календарь был готов после
         * открытия вкладки и не зависел от повторного клика по навигации. */
        loadAutopostCalendar();
    }());

    /* -- Utility: escape attribute value -- */
    function escAttr(str) {
        return str.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    /* -- Utility: escape HTML -- */
    function escHtml(str) {
        if (typeof str !== 'string') { return ''; }
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    /* -- Collapsible categories / tags (global, called via inline onclick) -- */
    window.wpRuMaxToggleTerms = function (btn, threshold) {
        var $btn    = jQuery(btn);
        var $labels = $btn.closest('td').find('.wp-ru-max-term-label');
        var isOpen  = $btn.data('wprmOpen');

        if ( isOpen ) {
            $labels.each(function (i) {
                if ( i >= threshold && ! jQuery(this).find('input').is(':checked') ) {
                    jQuery(this).css('display', 'none');
                }
            });
            $btn.text( $btn.data('more') ).data('wprmOpen', false);
        } else {
            $labels.css('display', 'inline-block');
            $btn.text( $btn.data('less') ).data('wprmOpen', true);
        }
    };

})(jQuery);
